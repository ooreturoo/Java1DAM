package menus;

public class InterfazMenu {

	public static void ImprimirMenu() {
		
		System.out.println("\n******PARKING******");
		System.out.println("1. Aparcar coche.");
		System.out.println("2. Ver coche aparcado.");
		System.out.println("3. Buscar coche por matrícula.");
		System.out.println("4. Calcular tarifa.");
		System.out.println("5. Salir");
		
	}
	
}

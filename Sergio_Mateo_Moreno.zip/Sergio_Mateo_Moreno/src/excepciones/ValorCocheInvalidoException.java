package excepciones;

public class ValorCocheInvalidoException extends Exception {

	
	private static final long serialVersionUID = 1L;
	
	
	public ValorCocheInvalidoException(String msg) {
		super(msg);
	}

}

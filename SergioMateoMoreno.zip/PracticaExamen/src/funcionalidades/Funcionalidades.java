package funcionalidades;

public class Funcionalidades {

	public static double pasarAMegaBytes(double bytes) {
		
		return (bytes / 1024) / 1024;
		
	}
}

package enums;

public enum CategoriaMensajes {
	HUMOR,
	DEPORTE,
	ESPORTS,
	EVENTOS,
	OTROS;
}

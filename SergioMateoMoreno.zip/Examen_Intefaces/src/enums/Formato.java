package enums;

public enum Formato {

	JPG,
	PNG,
	GIFF,
	PSD;
	
}

package interfaces;

public interface Convertible {

	/**
	 * Convierte cualquier dato.
	 * @return Devuelve un String.
	 */
	String convertir();
	
}

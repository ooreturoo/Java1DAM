package interfaces;

public interface Analizable {

	/**
	 * Analiza un elemento.
	 */
	void analizar();
	
}

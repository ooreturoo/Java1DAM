package interfaces;

public interface Reproducible {

	/**
	 * Reproduce el elemento que lo implementa.
	 */
	void reproducir();
	
}
